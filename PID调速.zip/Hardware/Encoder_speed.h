#ifndef   __Encoder_speed_h
#define  __Encoder_speed_h

void Encoder_Init_TIM4(void);

int Read_scale(void);

void Timer3_Init(void);

int Read_circle_count(void);
	
#endif
