#ifndef  __servo_h__
#define	 __servo_h__

void servo_init(void);

void Servo_SetAngle(float Angle);

#endif
