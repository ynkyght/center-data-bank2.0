#ifndef  __Motor_h__
#define  __Motor_h__

void Motor_Init(void);


void Motor_SetSpeed(int8_t Speed);


#endif
