#ifndef __Timer_calculation__
#define __Timer_calculation__

void Timer6_Init(void);

#endif
