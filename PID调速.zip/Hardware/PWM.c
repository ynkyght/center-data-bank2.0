#include "stm32f10x.h"                  // Device header

void PWM_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB2Periph_TIM1,ENABLE);
	
	//GPIO����
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	//��ʱ����
	TIM_InternalClockConfig(TIM1);//ѡ��ʱ��2
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitSturctrue;
	TIM_TimeBaseInitSturctrue.TIM_ClockDivision=TIM_CKD_DIV1;//�Ƿ��Ƶ
	TIM_TimeBaseInitSturctrue.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInitSturctrue.TIM_Period=100-1;//ARR�Զ���װ��	
	TIM_TimeBaseInitSturctrue.TIM_Prescaler=36-1;//PSCԤ��Ƶ��
	TIM_TimeBaseInitSturctrue.TIM_RepetitionCounter=0;//�߼���ʱ������
	TIM_TimeBaseInit(TIM1,&TIM_TimeBaseInitSturctrue);
	//����Ƚ�    
	TIM_OCInitTypeDef TIM_OCInitStructure;
	TIM_OCStructInit(&TIM_OCInitStructure);
	TIM_OCInitStructure.TIM_OCMode=TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OCPolarity=TIM_OCPolarity_High;
	TIM_OCInitStructure.TIM_OutputState=TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse=0;//ccr
	
		TIM_OC1Init(TIM1,&TIM_OCInitStructure);
		TIM_OC2Init(TIM1,&TIM_OCInitStructure);
		TIM_OC3Init(TIM1,&TIM_OCInitStructure);
		TIM_OC4Init(TIM1,&TIM_OCInitStructure);
	//ʹ��
	TIM_Cmd(TIM1,ENABLE);
}

void PWM_SetCompare1(uint16_t compare)
{
	TIM_SetCompare1(TIM1,compare);
}

void PWM_SetCompare2(uint16_t compare)
{
	TIM_SetCompare2(TIM1,compare);
}

void PWM_SetCompare3(uint16_t compare)
{
	TIM_SetCompare3(TIM1,compare);
}

void PWM_SetCompare4(uint16_t compare)
{
	TIM_SetCompare4(TIM1,compare);
}

/*
��Ƶ��Ϊ20khz��because:
pwm���Ƶ����Ƶ��Ϊ10khz--50khz
*/
