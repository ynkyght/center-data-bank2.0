#ifndef  __USART_H__
#define __USART_H__
#include "stm32f10x.h"                  // Device header
#include "stdio.h"

void NVIC_Configuration(void);
void USART_Configuration(void);
void USART_SendChar(USART_TypeDef* pUSARTx, uint8_t c);
void USART_SendString(USART_TypeDef* pUSARTx, char* str);

int fputc( int ch, FILE* f );
int fgetc(FILE* f);

#endif
