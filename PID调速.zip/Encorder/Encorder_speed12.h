#ifndef   __Encorder_speed12_h
#define  __Encorder_speed12_h

void Encoder_Init_TIM2(void);

int Read_scale(void);

int Read_circle_count(void);
	
#endif
