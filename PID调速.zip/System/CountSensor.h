#ifndef __CountSensor_h__

#define __CountSensor_h___

void CountSensor_Init(void);
uint16_t CountSensor_get(void);

#endif
