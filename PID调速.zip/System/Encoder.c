#include "stm32f10x.h"                  // Device header
uint16_t Encoder_conter;
void Encoder_Init(void)
{
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	
	GPIO_InitTypeDef GPIO_INITSTRCTURE;
	GPIO_INITSTRCTURE.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_INITSTRCTURE.GPIO_Pin=GPIO_Pin_1|GPIO_Pin_0;
//	GPIO_INITSTRCTURE.GPIO_Pin=GPIO_Pin_0;
	GPIO_INITSTRCTURE.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_INITSTRCTURE);
	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource0);	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource1);
	
	EXTI_InitTypeDef EXTI_INITSTRUCTURE;
	EXTI_INITSTRUCTURE.EXTI_Line=EXTI_Line0|EXTI_Line1;
	EXTI_INITSTRUCTURE.EXTI_LineCmd=ENABLE;
	EXTI_INITSTRUCTURE.EXTI_Mode=EXTI_Mode_Interrupt;
	EXTI_INITSTRUCTURE.EXTI_Trigger=EXTI_Trigger_Rising;
	
	EXTI_Init(&EXTI_INITSTRUCTURE);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_INITSTURCUTRE0;
	NVIC_INITSTURCUTRE0.NVIC_IRQChannel=EXTI0_IRQn;
	NVIC_INITSTURCUTRE0.NVIC_IRQChannelCmd=ENABLE;
	NVIC_INITSTURCUTRE0.NVIC_IRQChannelPreemptionPriority=1;
	NVIC_INITSTURCUTRE0.NVIC_IRQChannelSubPriority=1;
	NVIC_Init(&NVIC_INITSTURCUTRE0);
	
		NVIC_InitTypeDef NVIC_INITSTURCUTRE1;
	NVIC_INITSTURCUTRE1.NVIC_IRQChannel=EXTI1_IRQn;
	NVIC_INITSTURCUTRE1.NVIC_IRQChannelCmd=ENABLE;
	NVIC_INITSTURCUTRE1.NVIC_IRQChannelPreemptionPriority=1;
	NVIC_INITSTURCUTRE1.NVIC_IRQChannelSubPriority=2;
	NVIC_Init(&NVIC_INITSTURCUTRE1);
	
}

void EXTI0_IRQHandler (void)
{
	if(EXTI_GetFlagStatus(EXTI_Line0)==SET)
	{
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)==0)
			Encoder_conter--;
		EXTI_ClearITPendingBit(EXTI_Line0);
		
	}
}

void EXTI1_IRQHandler (void)
{
	if(EXTI_GetFlagStatus(EXTI_Line1)==SET)
	{	
	if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0)==0)
			Encoder_conter++;
		EXTI_ClearITPendingBit(EXTI_Line1);
	}
}
int16_t ENCODER_GET(void)
{
	int16_t tamp;
	tamp=Encoder_conter;
	Encoder_conter=0;
	return tamp;
}
