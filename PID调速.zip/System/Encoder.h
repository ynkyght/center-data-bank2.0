#ifndef __Encoder_h__

#define __Encoder_h__

void Encoder_Init(void);

void EXTI0_IRQHandler (void);

void EXTI1_IRQHandler (void);

int16_t ENCODER_GET(void);

#endif
