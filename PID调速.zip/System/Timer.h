#ifndef __Timer_h__

#define __Timer_h__


void Timer_Init(void);
uint16_t Timer_getcount(void);

#endif
