var driver__mpu6050__interface_8h =
[
    [ "mpu6050_interface_debug_print", "group__mpu6050__interface__driver.html#ga766f67d9a4579de12f966228ea1250f3", null ],
    [ "mpu6050_interface_delay_ms", "group__mpu6050__interface__driver.html#gaff78feee028c344ef7da403a23696b51", null ],
    [ "mpu6050_interface_dmp_orient_callback", "group__mpu6050__interface__driver.html#ga4885b5ea879f63878c1cb8cacbbc0f04", null ],
    [ "mpu6050_interface_dmp_tap_callback", "group__mpu6050__interface__driver.html#ga15f00112e11f9787ed2e5323968fdb6e", null ],
    [ "mpu6050_interface_iic_deinit", "group__mpu6050__interface__driver.html#ga4ad3030755a97f7067d958d34bfbdfe4", null ],
    [ "mpu6050_interface_iic_init", "group__mpu6050__interface__driver.html#gae82a00b862b6c02b4f76f5ccd3d820c6", null ],
    [ "mpu6050_interface_iic_read", "group__mpu6050__interface__driver.html#ga5ed51358859988d3b6168c1c34ff6571", null ],
    [ "mpu6050_interface_iic_write", "group__mpu6050__interface__driver.html#gaddddbfa804e2824445fea96c14e1b590", null ],
    [ "mpu6050_interface_receive_callback", "group__mpu6050__interface__driver.html#gaf09d98bce66f648d644cfe93f3ec5fe7", null ]
];