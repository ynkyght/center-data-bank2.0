var structmpu6050__handle__s =
[
    [ "buf", "structmpu6050__handle__s.html#a045a90c5f564ba839d93f865a4af28bc", null ],
    [ "debug_print", "structmpu6050__handle__s.html#a769d5b3a6c14790a0e126e8fe70b384b", null ],
    [ "delay_ms", "structmpu6050__handle__s.html#a406c9433252b7366de417b7a60915c81", null ],
    [ "dmp_inited", "structmpu6050__handle__s.html#a1316cdc70d1edc149d9f81612d972efc", null ],
    [ "dmp_orient_callback", "structmpu6050__handle__s.html#aacdc9ad9e84581d2899b222ea8f32d92", null ],
    [ "dmp_tap_callback", "structmpu6050__handle__s.html#a2a9335e7e0cb548b47827cdc2cded80d", null ],
    [ "iic_addr", "structmpu6050__handle__s.html#ae4fb63dc1b166464d5da3aa753b0805a", null ],
    [ "iic_deinit", "structmpu6050__handle__s.html#af6963bbad902ca6e43942b48c07986c3", null ],
    [ "iic_init", "structmpu6050__handle__s.html#a8826dd07625f8d90859ce9bd09628d61", null ],
    [ "iic_read", "structmpu6050__handle__s.html#af4ef726288b88f51a846483803a1249b", null ],
    [ "iic_write", "structmpu6050__handle__s.html#adca3ee7a793bbf510d5267daf0fcf1c5", null ],
    [ "inited", "structmpu6050__handle__s.html#a19bedf28d2b9748f6a62d9ae93f4e68f", null ],
    [ "mask", "structmpu6050__handle__s.html#a7fd850d4bb04f7410e8e2abf5f349348", null ],
    [ "orient", "structmpu6050__handle__s.html#a9ffc92f060368a3946c73ce1c3528452", null ],
    [ "receive_callback", "structmpu6050__handle__s.html#a4a9a1af4e28aea769f6d9f02a02e07c3", null ]
];