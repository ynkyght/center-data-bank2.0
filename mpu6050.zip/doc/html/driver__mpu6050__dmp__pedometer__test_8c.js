var driver__mpu6050__dmp__pedometer__test_8c =
[
    [ "mpu6050_dmp_pedometer_test", "group__mpu6050__test__driver.html#ga37d261cb133ede8d3c5d13ab1466397a", null ],
    [ "mpu6050_dmp_pedometer_test_irq_handler", "group__mpu6050__test__driver.html#ga54ac48254250e3b5b438642c48bbfbe3", null ]
];