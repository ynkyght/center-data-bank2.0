var structmpu6050__info__s =
[
    [ "chip_name", "structmpu6050__info__s.html#af890958c72bd715cc6454a10dc846ae6", null ],
    [ "driver_version", "structmpu6050__info__s.html#a41b0bd442708b70d252c50b92c75265a", null ],
    [ "interface", "structmpu6050__info__s.html#aebaa6c28dd4f2c3dc27566fcb910fd28", null ],
    [ "manufacturer_name", "structmpu6050__info__s.html#ad25285dbf810c90f8eaf3fcef6f2b2ea", null ],
    [ "max_current_ma", "structmpu6050__info__s.html#a9db82802561bf22d799b03a345f1d1dc", null ],
    [ "supply_voltage_max_v", "structmpu6050__info__s.html#a3d2b12bcac7a85ea8646bff9debe8660", null ],
    [ "supply_voltage_min_v", "structmpu6050__info__s.html#ad8bde6ddadaf43d951e62f3befb9d35a", null ],
    [ "temperature_max", "structmpu6050__info__s.html#a3366a5dce9b829e03c3d321c2b4df3f6", null ],
    [ "temperature_min", "structmpu6050__info__s.html#a8f9dbe66ac0b66ebae0a36fcb4ba368e", null ]
];