var annotated_dup =
[
    [ "mpu6050_handle_s", "structmpu6050__handle__s.html", "structmpu6050__handle__s" ],
    [ "mpu6050_info_s", "structmpu6050__info__s.html", "structmpu6050__info__s" ]
];