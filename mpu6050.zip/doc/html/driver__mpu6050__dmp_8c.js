var driver__mpu6050__dmp_8c =
[
    [ "mpu6050_dmp_deinit", "group__mpu6050__example__driver.html#ga36c91f910c116282ec9df4d972007fc5", null ],
    [ "mpu6050_dmp_get_pedometer_counter", "group__mpu6050__example__driver.html#ga5dc2e5196128effa5c85ca0c31011b5b", null ],
    [ "mpu6050_dmp_init", "group__mpu6050__example__driver.html#ga3298a755f9974bc3b2376ef576b52f4e", null ],
    [ "mpu6050_dmp_irq_handler", "group__mpu6050__example__driver.html#gae9dbe53d0c51253b78cd06fac28bd71f", null ],
    [ "mpu6050_dmp_read_all", "group__mpu6050__example__driver.html#gaa5f0a1219f072e02cd4c9bd0b4b29a18", null ]
];