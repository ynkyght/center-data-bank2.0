var group__mpu6050__extern__driver =
[
    [ "mpu6050_get_reg", "group__mpu6050__extern__driver.html#ga3d573edea87552d3af6d4e60fd1d4475", null ],
    [ "mpu6050_set_reg", "group__mpu6050__extern__driver.html#ga40023d18b00ff046ebd5accca0be8677", null ]
];