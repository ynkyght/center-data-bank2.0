var modules =
[
    [ "mpu6050 driver function", "group__mpu6050__driver.html", "group__mpu6050__driver" ]
];