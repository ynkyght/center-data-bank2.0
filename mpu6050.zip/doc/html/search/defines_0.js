var searchData=
[
  ['chip_5fname_1049',['CHIP_NAME',['../driver__mpu6050_8c.html#adc9da0a24824ca1239b593f6459b3954',1,'driver_mpu6050.c']]]
];
