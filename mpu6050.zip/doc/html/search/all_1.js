var searchData=
[
  ['chip_5fname_1',['chip_name',['../structmpu6050__info__s.html#af890958c72bd715cc6454a10dc846ae6',1,'mpu6050_info_s']]],
  ['chip_5fname_2',['CHIP_NAME',['../driver__mpu6050_8c.html#adc9da0a24824ca1239b593f6459b3954',1,'driver_mpu6050.c']]]
];
