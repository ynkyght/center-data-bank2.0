var searchData=
[
  ['manufacturer_5fname_880',['manufacturer_name',['../structmpu6050__info__s.html#ad25285dbf810c90f8eaf3fcef6f2b2ea',1,'mpu6050_info_s']]],
  ['mask_881',['mask',['../structmpu6050__handle__s.html#a7fd850d4bb04f7410e8e2abf5f349348',1,'mpu6050_handle_s']]],
  ['max_5fcurrent_5fma_882',['max_current_ma',['../structmpu6050__info__s.html#a9db82802561bf22d799b03a345f1d1dc',1,'mpu6050_info_s']]]
];
