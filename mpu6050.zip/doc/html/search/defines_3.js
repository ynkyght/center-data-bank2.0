var searchData=
[
  ['supply_5fvoltage_5fmax_1169',['SUPPLY_VOLTAGE_MAX',['../driver__mpu6050_8c.html#a68eba8b601afe11f1b871d944976c035',1,'driver_mpu6050.c']]],
  ['supply_5fvoltage_5fmin_1170',['SUPPLY_VOLTAGE_MIN',['../driver__mpu6050_8c.html#aac8d8cbd899667d609787ef4cf37054d',1,'driver_mpu6050.c']]]
];
