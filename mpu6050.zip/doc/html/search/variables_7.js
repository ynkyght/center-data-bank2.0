var searchData=
[
  ['supply_5fvoltage_5fmax_5fv_885',['supply_voltage_max_v',['../structmpu6050__info__s.html#a3d2b12bcac7a85ea8646bff9debe8660',1,'mpu6050_info_s']]],
  ['supply_5fvoltage_5fmin_5fv_886',['supply_voltage_min_v',['../structmpu6050__info__s.html#ad8bde6ddadaf43d951e62f3befb9d35a',1,'mpu6050_info_s']]]
];
