var driver__mpu6050__dmp__tap__orient__motion__test_8h =
[
    [ "mpu6050_dmp_tap_orient_motion_test", "group__mpu6050__test__driver.html#gaf37461061063d0daa12656bf9a1bc0d4", null ],
    [ "mpu6050_dmp_tap_orient_motion_test_irq_handler", "group__mpu6050__test__driver.html#gabc948206de49b1449a6a764b2be2e0a8", null ]
];